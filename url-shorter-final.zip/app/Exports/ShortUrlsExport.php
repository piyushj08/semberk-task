<?php

namespace App\Exports;

use App\Models\ShortUrl;
use Carbon\Carbon;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ShortUrlsExport implements FromCollection, WithHeadings
{
    protected $filter;

    public function __construct($filter = null)
    {
        $this->filter = $filter;
    }

    public function collection()
    {
        $urls = ShortUrl::query();

        if ($this->filter === 'today') {
            $urls->whereDate('created_at', Carbon::today());
        } elseif ($this->filter === 'last_week') {
            $urls->whereBetween('created_at', [Carbon::now()->subWeek(), Carbon::now()]);
        } elseif ($this->filter === 'this_month') {
            $urls->whereMonth('created_at', Carbon::now()->month)
                 ->whereYear('created_at', Carbon::now()->year);
        } elseif ($this->filter === 'last_month') {
            $urls->whereMonth('created_at', Carbon::now()->subMonth()->month)
                 ->whereYear('created_at', Carbon::now()->subMonth()->year);
        }

        return $urls->latest()->get(['id', 'original_url', 'shortened_url', 'hit_count', 'created_at']);
    }

    public function headings(): array
    {
        return ['ID', 'Original URL', 'Shortened URL', 'Hits', 'Created At'];
    }
}
