<?php

namespace App\Http\Controllers;

use App\Exports\ShortUrlsExport;
use App\Models\ShortUrl;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class DashboardController extends Controller
{
    public function dashboard(Request $request)
    {
        $filter = $request->query('filter');

        $urls = ShortUrl::with('creator');

        if ($filter === 'today') {
            $urls->whereDate('created_at', Carbon::today());
        } elseif ($filter === 'last_week') {
            $urls->whereBetween('created_at', [Carbon::now()->subWeek(), Carbon::now()]);
        } elseif ($filter === 'this_month') {
            $urls->whereMonth('created_at', Carbon::now()->month)
                ->whereYear('created_at', Carbon::now()->year);
        } elseif ($filter === 'last_month') {
            $urls->whereMonth('created_at', Carbon::now()->subMonth()->month)
                ->whereYear('created_at', Carbon::now()->subMonth()->year);
        }

        $urls = $urls->latest()->paginate(10);

        $admins = User::with(['company.users', 'company.shortUrls'])
            ->where('role', 'Admin')
            ->paginate(10);

        return view('dashboard', compact('admins', 'urls', 'filter'));
    }

    public function adminDashboard(Request $request)
    {
        $filter = $request->query('filter');

        // Filter URLs
        $urls = ShortUrl::with('creator');

        if ($filter === 'today') {
            $urls->whereDate('created_at', Carbon::today());
        } elseif ($filter === 'last_week') {
            $urls->whereBetween('created_at', [Carbon::now()->subWeek(), Carbon::now()]);
        } elseif ($filter === 'this_month') {
            $urls->whereMonth('created_at', Carbon::now()->month)
                ->whereYear('created_at', Carbon::now()->year);
        } elseif ($filter === 'last_month') {
            $urls->whereMonth('created_at', Carbon::now()->subMonth()->month)
                ->whereYear('created_at', Carbon::now()->subMonth()->year);
        }

        $urls = $urls->latest()->paginate(10);

        // Members list (with their shortUrls)
        $members = User::with('shortUrls')
            ->where('role', 'Member')
            ->paginate(10);

        return view('dashboard.admin-dashboard', compact('members', 'urls', 'filter'));
    }

    public function userDashboard(Request $request)
    {
        $filter = $request->query('filter');
        $urls = ShortUrl::query();

        if ($filter === 'today') {
            $urls->whereDate('created_at', Carbon::today());
        } elseif ($filter === 'last_week') {
            $urls->whereBetween('created_at', [Carbon::now()->subWeek(), Carbon::now()]);
        } elseif ($filter === 'this_month') {
            $urls->whereMonth('created_at', Carbon::now()->month)
                ->whereYear('created_at', Carbon::now()->year);
        } elseif ($filter === 'last_month') {
            $urls->whereMonth('created_at', Carbon::now()->subMonth()->month)
                ->whereYear('created_at', Carbon::now()->subMonth()->year);
        }
        $urls = $urls->latest()->paginate(10);

        return view('dashboard.member-dashboard', compact('urls', 'filter'));
    }

    public function downloadUrls(Request $request)
    {
        $filter = $request->query('filter');
        return Excel::download(new ShortUrlsExport($filter), 'short_urls.xlsx');
    }
}
