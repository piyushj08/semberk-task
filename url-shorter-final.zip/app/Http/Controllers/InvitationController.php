<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Mail;

class InvitationController extends Controller
{
    public function create()
    {
        $companies = Company::orderBy('name')->get(['id', 'name']);
        return view('invitations.superadmin-create', compact('companies'));
    }

    public function store(Request $request)
    {
        $user = $request->user();

        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'c_name' => ['required', 'string', 'max:255', 'unique:companies,name'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8'],
        ]);


        $company = Company::create([
            'name' => $data['c_name'],
        ]);

        $admin = User::create([
            'name'       => $data['name'],
            'email'      => $data['email'],
            'role'       => 'Admin',
            'company_id' => $company->id,
            'password'   => Hash::make($data['password']),
        ]);

        // Send HTML Email with details
        Mail::html("
            <h2>Welcome, {$admin->name}!</h2>
            <p>Your Admin account has been created successfully for the company <strong>{$company->name}</strong>.</p>
            <p><strong>Login Email:</strong> {$admin->email}</p>
            <p><strong>Password:</strong> {$data['password']}</p>
            <p>You can log in here: <a href='" . url('/login') . "'>" . url('/login') . "</a></p>", function ($message) use ($admin) {
            $message->to($admin->email)
                ->subject('Your Admin Account Has Been Created');
        });


        return redirect()->route('dashboard')->with('status', "Company {$company->name} created and Admin {$admin->email} invited successfully.");
    }


    public function listView()
    {
        $admins = User::with(['company.users', 'company.shortUrls'])
        ->where('role', 'Admin')
        ->paginate(10);
        return view('invitations.all-listview', compact('admins'));
    }
}
