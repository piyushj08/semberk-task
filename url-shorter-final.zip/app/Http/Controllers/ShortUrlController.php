<?php

namespace App\Http\Controllers;

use App\Models\ShortUrl;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Str;

class ShortUrlController extends Controller
{

    public function create()
    {
        return view('short_urls.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'original_url' => ['required', 'url', 'max:2048'],
        ]);

        $user = $request->user();
        $code = Str::random(8);
        while (ShortUrl::where('code', $code)->exists()) $code = Str::random(8);

        $short = ShortUrl::create([
            'code' => $code,
            'original_url' => $data['original_url'],
            'shortened_url' => url("/s/{$code}"),
            'company_id' => $user->company_id,
            'created_by' => $user->id,
        ]);
        if (Auth::user()->role === 'Admin') {
            return redirect()->route('admin.dashboard')->with('status', "Created {$short->shortened_url}");
        } else {
            return redirect()->route('user.dashboard')->with('status', "Created {$short->shortened_url}");
        }
    }

    public function redirect($code)
    {
        $short = ShortUrl::where('code', $code)->firstOrFail();

        // increment hit counter
        $short->increment('hit_count');

        // redirect to original URL
        return redirect()->away($short->original_url);
    }

    public function shortListView()
    {
        $urls = ShortUrl::with('creator')->latest()->paginate(10);
        return view('short_urls.super-list-view', compact('urls'));
    }
}
