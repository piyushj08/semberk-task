<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

class TeamController extends Controller
{
    public function create()
    {
        $companies = Company::orderBy('name')->get(['id', 'name']);
        return view('team.create-team', compact('companies'));
    }

    public function store(Request $request)
    {
        $user = $request->user();

        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'role' => ['required'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8'],
        ]);

        $member = User::create([
            'name'       => $data['name'],
            'email'      => $data['email'],
            'role'       => $data['role'],
            'company_id' => auth()->user()->company_id,
            'password'   => Hash::make($data['password']),
        ]);

        // Send HTML Email with details
        Mail::html("
            <h2>Welcome, {$member->name}!</h2>
            <p>Your Member account has been created successfully.</p>
            <p><strong>Login Email:</strong> {$member->email}</p>
            <p><strong>Password:</strong> {$data['password']}</p>
            <p>You can log in here: <a href='" . url('/login') . "'>" . url('/login') . "</a></p>", function ($message) use ($member) {
            $message->to($member->email)
                ->subject('Your Member Account Has Been Created');
        });


        return redirect()->route('admin.dashboard')->with('status', "Member {$member->email} invited successfully.");
    }


    public function teamListView()
    {
        $members = User::with(['shortUrls'])->where('role', 'Member')
        ->paginate(10);
        return view('team.list-view', compact('members'));
    }
}
