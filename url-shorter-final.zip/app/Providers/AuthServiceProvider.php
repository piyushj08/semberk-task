<?php

namespace App\Providers;

use App\Models\ShortUrl;
use App\Models\User;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    protected $policies = [];

    public function boot(): void
    {
        // Who can CREATE short urls? Only Sales or Manager
        Gate::define('short.create', fn(User $u) => in_array($u->role, ['Sales','Manager']));

        // Who can LIST (index)?
        Gate::define('short.index', function (User $u, ?string $scope = null) {
            // SuperAdmin: cannot see "list of all short urls for every company"
            if ($u->is('SuperAdmin')) return false;

            // Admin: only urls NOT in their own company
            if ($u->is('Admin')) return true; // filtering happens in controller

            // Member: only urls NOT created by themselves
            if ($u->is('Member')) return true; // filtering happens in controller

            // Sales/Manager: they may want to see all in their own company only (not requested, but safe default)
            return true;
        });

        // Who can RESOLVE via short code? Require auth; all logged-in users allowed.
        Gate::define('short.resolve', fn(User $u) => true);
    }
}
