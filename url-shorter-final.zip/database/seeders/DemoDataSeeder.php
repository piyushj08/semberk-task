<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\Company;
use App\Models\User;

class DemoDataSeeder extends Seeder
{
    public function run(): void
    {
        // Companies
        $c1 = Company::firstOrCreate(['name' => 'ABC Corp']);
        $c2 = Company::firstOrCreate(['name' => 'BMN Ltd']);

        // Admin user
        $sales = User::factory()->create([
            'company_id' => $c1->id,
            'role'       => 'Admin',
            'email'      => 'sales@abc.com',
            'name'       => 'Mohan',
            'password'   => Hash::make('Mohan@1234'),
        ]);

        // Member user
        $mgr = User::factory()->create([
            'company_id' => $c2->id,
            'role'       => 'Member',
            'email'      => 'manager@bmn.com',
            'name'       => 'Ravi',
            'password'   => Hash::make('Ravi@1234'),
        ]);
    }
}
