<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class SuperAdminSeeder extends Seeder
{
    public function run(): void
    {

        DB::table('companies')->insertOrIgnore(['id'=>1,'name'=>'Acme Inc','created_at'=>now(),'updated_at'=>now()]);


        DB::statement("
            INSERT INTO users (name, email, password, role, company_id, created_at, updated_at)
            VALUES ('Super Admin', 'superadmin@gmail.com', '".Hash::make('Test@123')."', 'SuperAdmin', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            ON DUPLICATE KEY UPDATE email = email
        ");
    }
}
