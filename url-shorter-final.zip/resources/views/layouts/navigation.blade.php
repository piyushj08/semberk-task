<!-- Header -->
<div class="bg-white shadow flex justify-between items-center p-4">
    <h2 class="font-bold text-lg">🔗 Dashboard</h2>
    </a>
    <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        Logout
    </a>
</div>
<form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
    @csrf
</form>
