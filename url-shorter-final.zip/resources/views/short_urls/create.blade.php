@extends('layouts.app')
@section('content')
    <!-- Invite Client Section -->
    <div class="max-w-4xl mx-auto p-6">
        <h2 class="text-xl font-semibold text-blue-600 mb-4">Generate Short URL</h2>

        <!-- Form Card -->
        <div class="bg-white shadow border rounded-lg p-6">
            <form action="{{ route('short.store') }}" method="POST" class="space-y-6">
                @csrf
                <div>
                    <label for="original_url" class="block text-sm font-medium text-gray-700 mb-1">Long URL</label>
                    <input type="text" id="original_url" name="original_url" value="{{ old('original_url') }}"
                        placeholder="Enter Long URL..." required
                        class="w-full border border-gray-400 rounded px-3 py-2 focus:ring-2 focus:ring-indigo-400 focus:outline-none @error('name') border-red-500 @enderror">
                    @error('original_url')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>
                <!-- Submit -->
                <div>
                    <button type="submit"
                        class="bg-blue-500 text-white font-semibold px-6 py-2 rounded border border-blue-600 hover:bg-blue-600 transition">
                        Generate
                    </button>
                    <button type="button" onclick="history.back()"
                        class="bg-gray-500 text-white font-semibold px-6 py-2 rounded border border-gray-600 hover:bg-gray-600 transition">
                        Back
                    </button>

                </div>
            </form>

        </div>
    @endsection
