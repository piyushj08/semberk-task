<x-app-layout>
    <x-slot name="header"><h2>Short URLs</h2></x-slot>

    @can('short.create') <a href="{{ route('short.create') }}">Create Short URL</a> @endcan

    @if(session('status')) <p>{{ session('status') }}</p> @endif

    <table>
        <thead><tr><th>Code</th><th>Original</th><th>Company</th><th>Creator</th></tr></thead>
        <tbody>
        @foreach($urls as $u)
            <tr>
                <td>{{ $u->code }}</td>
                <td>{{ $u->original_url }}</td>
                <td>{{ optional($u->company)->name ?? '—' }}</td>
                <td>{{ $u->creator->name }} ({{ $u->creator->role }})</td>
            </tr>
        @endforeach
        </tbody>
    </table>

    {{ $urls->links() }}
</x-app-layout>
