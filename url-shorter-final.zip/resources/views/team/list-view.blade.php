@extends('layouts.app')
@section('content')
    <section class="px-6 py-6">
        <div class="flex justify-between items-center mb-4">
            <div class="flex items-center gap-4">
                <h2 class="text-xl font-semibold text-blue-700">Team Members</h2>
                <button type="button" onclick="history.back()"
                    class="bg-gray-500 text-white font-semibold px-6 py-2 rounded border border-gray-600 hover:bg-gray-600 transition">
                    Back
                </button>
            </div>

            <a href="{{ route('team.create') }}"
                class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700">Invite</a>
        </div>

        <div class="overflow-x-auto bg-white rounded-lg shadow">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-100 text-left">
                        <th class="px-4 py-2 border">Name</th>
                        <th class="px-4 py-2 border">Email</th>
                        <th class="px-4 py-2 border">Role</th>
                        <th class="px-4 py-2 border">Total Generated URLs</th>
                        <th class="px-4 py-2 border">Total URL Hits</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($members as $member)
                        @php
                            $totalUrls = $member?->shortUrls->count() ?? 0;
                            $totalHits = $member?->shortUrls->sum('hit_count') ?? 0;
                        @endphp
                        <tr>
                            <td class="px-4 py-2 border">
                                {{ $member->name ?? 'N/A' }}
                            </td>
                            <td class="px-4 py-2 border">
                                {{ $member->email ?? 'N/A' }}
                            </td>
                            <td class="px-4 py-2 border">
                                {{ $member->role ?? 'N/A' }}
                            </td>
                            <td class="px-4 py-2 border">
                                {{ $totalUrls ?? 'N/A' }}
                            </td>
                            <td class="px-4 py-2 border">
                                {{ $totalHits ?? 'N/A' }}
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4" class="px-4 py-2 border text-center text-gray-500">
                                No Admin data available.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>

        </div>

        <div class="flex justify-between items-center mt-3 text-sm">
            <span class="text-sm text-gray-600">
                Showing {{ $members->firstItem() }} to {{ $members->lastItem() }}
                of {{ $members->total() }}
            </span>
          <div>
            {{  $members->links() }}
          </div>
        </div>
    </section>
@endsection
