<?php

use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InvitationController;
use App\Http\Controllers\ShortUrlController;
use App\Http\Controllers\TeamController;

Route::get('/', function () {
    return view('home');
});


Route::middleware('auth')->group(function () {

    Route::get('/dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');
    Route::get('/admin/dashboard', [DashboardController::class, 'adminDashboard'])->name('admin.dashboard');
    Route::get('/user/dashboard', [DashboardController::class, 'userDashboard'])->name('user.dashboard');
    // Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    // Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    // Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // URL Shortener
    Route::get('/short', [ShortUrlController::class, 'index'])->name('short.index');
    Route::get('/short/create', [ShortUrlController::class, 'create'])->name('short.create');
    Route::post('/short', [ShortUrlController::class, 'store'])->name('short.store');
    Route::get('/short/list-all', [ShortUrlController::class, 'shortListView'])->name('short.list.all');

    // Invitations
    Route::get('/invite', [InvitationController::class, 'create'])->name('invite.create');
    Route::post('/invite', [InvitationController::class, 'store'])->name('invite.store');
    Route::get('/invite/list', [InvitationController::class, 'listView'])->name('invite.list.all');

    // Team Members
    Route::get('/team/creae', [TeamController::class, 'create'])->name('team.create');
    Route::post('/team/store', [TeamController::class, 'store'])->name('team.store');
    Route::get('/team/list', [TeamController::class, 'teamListView'])->name('team.list.all');

    Route::get('/download-urls', [DashboardController::class, 'downloadUrls'])->name('urls.download');
});

Route::get('/s/{code}', [ShortUrlController::class, 'redirect'])->name('short.redirect');

require __DIR__ . '/auth.php';
