<?php $__env->startSection('content'); ?>
    <!-- Generated Short URLs Section -->
    <section class="px-6 py-6">
        <div class="flex justify-between items-center mb-4">
            <div class="flex items-center gap-4">
            <h2 class="text-xl font-semibold text-blue-700">Generated Short URLs</h2>
            <button type="button" onclick="history.back()"
            class="bg-gray-500 text-white font-semibold px-6 py-2 rounded border border-gray-600 hover:bg-gray-600 transition">
            Back
        </button>
        </div>
            <div class="flex items-center gap-3">
                <select class="border rounded px-3 py-2 text-sm">
                    <option>This Month</option>
                    <option>Last Month</option>
                    <option>Last Week</option>
                    <option>Today</option>
                </select>
                <button class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700">Download</button>
            </div>
        </div>

        <div class="overflow-x-auto bg-white rounded-lg shadow">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-100 text-left">
                        <th class="px-4 py-2 border">Short URL</th>
                        <th class="px-4 py-2 border">Long URL</th>
                        <th class="px-4 py-2 border">Hits</th>
                        <th class="px-4 py-2 border">Client</th>
                        <th class="px-4 py-2 border">Created On</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-4 py-2 border"><?php echo e($url->shortened_url); ?></td>
                            <td class="px-4 py-2 border truncate max-w-xs"><?php echo e($url->original_url); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($url->hit_count); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($url->creator->name); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($url->created_at->format('d M \'y')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="flex justify-between items-center mt-3 text-sm">
            <span class="text-sm text-gray-600">
                Showing <?php echo e($urls->firstItem()); ?> to <?php echo e($urls->lastItem()); ?>

                of <?php echo e($urls->total()); ?>

            </span>
            <div>
                <?php echo e($urls->links()); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pc\Music\url-shortener\resources\views\short_urls\super-list-view.blade.php ENDPATH**/ ?>