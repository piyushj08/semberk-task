<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sembark URL Shortener</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 text-gray-800">

  <!-- Navbar -->
  <header class="bg-white shadow">
    <div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
      <h1 class="text-2xl font-bold text-indigo-600">Sembark URL Shortener</h1>
      <nav class="space-x-6">

        <a href="<?php echo e(route('login')); ?>" class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">Login</a>
      </nav>
    </div>
  </header>

  <!-- Hero Section -->
  <section class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-20">
    <div class="max-w-5xl mx-auto text-center">
      <h2 class="text-4xl font-bold mb-4">Shorten. Track. Manage.</h2>
      <p class="text-lg mb-6">A powerful URL shortener with analytics and client management dashboard.</p>
      <a href="<?php echo e(route('login')); ?>" class="px-6 py-3 bg-white text-indigo-600 font-semibold rounded-lg shadow hover:bg-gray-100">
        Get Started Free
      </a>
    </div>
  </section>

  <!-- Features -->
  <section id="features" class="py-16 max-w-6xl mx-auto px-6">
    <h3 class="text-3xl font-bold text-center mb-12">Key Features</h3>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
      <div class="p-6 bg-white rounded-lg shadow">
        <h4 class="font-semibold text-xl mb-2">Custom Short Links</h4>
        <p>Create branded short links to share across platforms.</p>
      </div>
      <div class="p-6 bg-white rounded-lg shadow">
        <h4 class="font-semibold text-xl mb-2">Analytics</h4>
        <p>Track clicks, referrals, and geographic insights in real-time.</p>
      </div>
      <div class="p-6 bg-white rounded-lg shadow">
        <h4 class="font-semibold text-xl mb-2">Multi-Client Management</h4>
        <p>Super admin can manage multiple companies, users, and usage stats.</p>
      </div>
    </div>
  </section>

  <!-- Pricing -->
  <section id="pricing" class="py-16 bg-gray-100">
    <div class="max-w-6xl mx-auto text-center">
      <h3 class="text-3xl font-bold mb-12">Simple Pricing</h3>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="p-6 bg-white rounded-lg shadow">
          <h4 class="text-xl font-semibold mb-2">Free</h4>
          <p class="mb-4">Basic link shortening</p>
          <p class="font-bold text-2xl mb-4">$0</p>
          <a href="<?php echo e(route('login')); ?>" class="px-4 py-2 bg-indigo-600 text-white rounded-lg">Start Free</a>
        </div>
        <div class="p-6 bg-white rounded-lg shadow border-2 border-indigo-600">
          <h4 class="text-xl font-semibold mb-2">Pro</h4>
          <p class="mb-4">Advanced analytics & branding</p>
          <p class="font-bold text-2xl mb-4">$19/mo</p>
          <a href="#" class="px-4 py-2 bg-indigo-600 text-white rounded-lg">Get Pro</a>
        </div>
        <div class="p-6 bg-white rounded-lg shadow">
          <h4 class="text-xl font-semibold mb-2">Enterprise</h4>
          <p class="mb-4">Full features + dedicated support</p>
          <p class="font-bold text-2xl mb-4">$80/mo</p>
          <a href="#" class="px-4 py-2 bg-indigo-600 text-white rounded-lg">Get Enterprise</a>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer id="contact" class="bg-gray-800 text-gray-300 py-8">
    <div class="max-w-6xl mx-auto text-center">
      <p>© 2025 Sembark URL Shortener. All rights reserved.</p>
      <p class="mt-2">Contact: support@sembark.com</p>
    </div>
  </footer>

</body>
</html>
<?php /**PATH C:\Users\pc\Music\url-shortener\resources\views\home.blade.php ENDPATH**/ ?>