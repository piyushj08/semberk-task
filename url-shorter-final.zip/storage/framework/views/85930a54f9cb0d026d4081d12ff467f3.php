<?php $__env->startSection('content'); ?>
    <section class="px-6 py-6">
        <div class="flex justify-between items-center mb-4">
            <div class="flex items-center gap-4">
                <h2 class="text-xl font-semibold text-blue-700">Team Members</h2>
                <button type="button" onclick="history.back()"
                    class="bg-gray-500 text-white font-semibold px-6 py-2 rounded border border-gray-600 hover:bg-gray-600 transition">
                    Back
                </button>
            </div>

            <a href="<?php echo e(route('team.create')); ?>"
                class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700">Invite</a>
        </div>

        <div class="overflow-x-auto bg-white rounded-lg shadow">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-100 text-left">
                        <th class="px-4 py-2 border">Name</th>
                        <th class="px-4 py-2 border">Email</th>
                        <th class="px-4 py-2 border">Role</th>
                        <th class="px-4 py-2 border">Total Generated URLs</th>
                        <th class="px-4 py-2 border">Total URL Hits</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $totalUrls = $member?->shortUrls->count() ?? 0;
                            $totalHits = $member?->shortUrls->sum('hit_count') ?? 0;
                        ?>
                        <tr>
                            <td class="px-4 py-2 border">
                                <?php echo e($member->name ?? 'N/A'); ?>

                            </td>
                            <td class="px-4 py-2 border">
                                <?php echo e($member->email ?? 'N/A'); ?>

                            </td>
                            <td class="px-4 py-2 border">
                                <?php echo e($member->role ?? 'N/A'); ?>

                            </td>
                            <td class="px-4 py-2 border">
                                <?php echo e($totalUrls ?? 'N/A'); ?>

                            </td>
                            <td class="px-4 py-2 border">
                                <?php echo e($totalHits ?? 'N/A'); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="px-4 py-2 border text-center text-gray-500">
                                No Admin data available.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>

        <div class="flex justify-between items-center mt-3 text-sm">
            <span class="text-sm text-gray-600">
                Showing <?php echo e($members->firstItem()); ?> to <?php echo e($members->lastItem()); ?>

                of <?php echo e($members->total()); ?>

            </span>
          <div>
            <?php echo e($members->links()); ?>

          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pc\Music\url-shortener\resources\views\team\list-view.blade.php ENDPATH**/ ?>