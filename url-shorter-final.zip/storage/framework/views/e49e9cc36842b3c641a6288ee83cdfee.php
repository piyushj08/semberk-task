<!-- Header -->
<div class="bg-white shadow flex justify-between items-center p-4">
    <h2 class="font-bold text-lg">🔗 Dashboard</h2>
    </a>
    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        Logout
    </a>
</div>
<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
    <?php echo csrf_field(); ?>
</form>
<?php /**PATH C:\Users\pc\Music\url-shortener\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>