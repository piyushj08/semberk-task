<?php $__env->startSection('content'); ?>
    <!-- Clients Section -->
    <section class="px-6 py-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-semibold text-blue-700">Admins</h2>
            <a href="<?php echo e(route('invite.create')); ?>"
                class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700">Invite</a>
        </div>

        <div class="overflow-x-auto bg-white rounded-lg shadow">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-100 text-left">
                        <th class="px-4 py-2 border">Admin Name</th>
                        <th class="px-4 py-2 border">Users</th>
                        <th class="px-4 py-2 border">Total Generated URLs</th>
                        <th class="px-4 py-2 border">Total URL Hits</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $company = $admin->company;
                            $totalUsers = $company?->users->count() ?? 0;
                            $totalUrls = $company?->shortUrls->count() ?? 0;
                            $totalHits = $company?->shortUrls->sum('hit_count') ?? 0;
                        ?>

                        <tr>
                            <td class="px-4 py-2 border">
                                <?php echo e($admin->company->name ?? 'N/A'); ?>

                                <br>
                                <span class="text-sm text-gray-500"><?php echo e($admin->email); ?></span>
                            </td>
                            <td class="px-4 py-2 border">
                                <?php echo e($totalUsers); ?>

                            </td>
                            <td class="px-4 py-2 border">
                                <?php echo e($totalUrls); ?>

                            </td>
                            <td class="px-4 py-2 border">
                                <?php echo e($totalHits); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="px-4 py-2 border text-center text-gray-500">
                                No Admin data available.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>

        <div class="flex justify-between items-center mt-3 text-sm">
            <span class="text-sm text-gray-600">
                Showing <?php echo e($admins->firstItem()); ?> to <?php echo e($admins->lastItem()); ?>

                of <?php echo e($admins->total()); ?>

            </span>
            <a href="<?php echo e(route('invite.list.all')); ?>"
                class="px-3 py-1 border border-blue-500 text-blue-600 rounded hover:bg-blue-500 hover:text-white">View
                All</a>
        </div>
    </section>

    <!-- Generated Short URLs Section -->
    <section class="px-6 py-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-semibold text-blue-700">Generated Short URLs</h2>
            <div class="flex items-center gap-3">
                <select class="border rounded px-3 py-2 text-sm">
                    <option>This Month</option>
                    <option>Last Month</option>
                    <option>Last Week</option>
                    <option>Today</option>
                </select>
                <button class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700">Download</button>
            </div>
        </div>

        <div class="overflow-x-auto bg-white rounded-lg shadow">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-100 text-left">
                        <th class="px-4 py-2 border">Short URL</th>
                        <th class="px-4 py-2 border">Long URL</th>
                        <th class="px-4 py-2 border">Hits</th>
                        <th class="px-4 py-2 border">Client</th>
                        <th class="px-4 py-2 border">Created On</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-4 py-2 border"><?php echo e($url->shortened_url); ?></td>
                            <td class="px-4 py-2 border truncate max-w-xs"><?php echo e($url->original_url); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($url->hit_count); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($url->creator->name); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($url->created_at->format('d M \'y')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="flex justify-between items-center mt-3 text-sm">
            <span class="text-sm text-gray-600">
                Showing <?php echo e($urls->firstItem()); ?> to <?php echo e($urls->lastItem()); ?>

                of <?php echo e($urls->total()); ?>

            </span>
            <a href="<?php echo e(route('short.list.all')); ?>"
                class="px-3 py-1 border border-blue-500 text-blue-600 rounded hover:bg-blue-500 hover:text-white">View
                All</a>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pc\Music\url-shortener\resources\views\dashboard.blade.php ENDPATH**/ ?>