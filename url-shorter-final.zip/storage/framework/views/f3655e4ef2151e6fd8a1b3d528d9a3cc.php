<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
    <div class="max-w-4xl mx-auto p-6">
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
            <strong class="font-bold">Success!</strong>
            <span class="block sm:inline"><?php echo e(session('status')); ?></span>
            <span class="absolute top-0 bottom-0 right-0 px-4 py-3">
                <svg class="fill-current h-6 w-6 text-green-500" role="button" onclick="this.parentElement.parentElement.style.display='none';" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
            </span>
        </div>
    </div>
<?php endif; ?>
<?php if($errors->all()): ?>
    <div class="max-w-4xl mx-auto p-6">
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
            <strong class="font-bold">Error!</strong>
            <ul class="list-disc list-inside">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <span class="absolute top-0 bottom-0 right-0 px-4 py-3">
                <svg class="fill-current h-6 w-6 text-red-500" role="button" onclick="this.parentElement.parentElement.style.display='none';" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2       1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
                    </span>
        </div>
    </div>
<?php endif; ?>
    <!-- Generated Short URLs Section -->
    <section class="px-6 py-6">
        <div class="flex justify-between items-center mb-4">
            <div class="flex items-center gap-4">
                <h2 class="text-xl font-semibold text-blue-700">Generated Short URLs</h2>
                <a href="<?php echo e(route('short.create')); ?>"
                    class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700">Generate</a>
            </div>
            <div class="flex items-center gap-3">
                <select class="border rounded px-3 py-2 text-sm">
                    <option>This Month</option>
                    <option>Last Month</option>
                    <option>Last Week</option>
                    <option>Today</option>
                </select>
                <button class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700">Download</button>
            </div>
        </div>

        <div class="overflow-x-auto bg-white rounded-lg shadow">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-100 text-left">
                        <th class="px-4 py-2 border">Short URL</th>
                        <th class="px-4 py-2 border">Long URL</th>
                        <th class="px-4 py-2 border">Hits</th>
                        <th class="px-4 py-2 border">Client</th>
                        <th class="px-4 py-2 border">Created On</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-4 py-2 border"><?php echo e($url->shortened_url); ?></td>
                            <td class="px-4 py-2 border truncate max-w-xs"><?php echo e($url->original_url); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($url->hit_count); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($url->creator->name); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($url->created_at->format('d M \'y')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="flex justify-between items-center mt-3 text-sm">
            <span class="text-sm text-gray-600">
                Showing <?php echo e($urls->firstItem()); ?> to <?php echo e($urls->lastItem()); ?>

                of <?php echo e($urls->total()); ?>

            </span>
            <a href="<?php echo e(route('short.list.all')); ?>"
                class="px-3 py-1 border border-blue-500 text-blue-600 rounded hover:bg-blue-500 hover:text-white">View
                All</a>
        </div>
    </section>

    <section class="px-6 py-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-semibold text-blue-700">Team Members</h2>
            <a href="<?php echo e(route('team.create')); ?>"
                class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700">Invite</a>
        </div>

        <div class="overflow-x-auto bg-white rounded-lg shadow">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-100 text-left">
                        <th class="px-4 py-2 border">Name</th>
                        <th class="px-4 py-2 border">Email</th>
                        <th class="px-4 py-2 border">Role</th>
                        <th class="px-4 py-2 border">Total Generated URLs</th>
                        <th class="px-4 py-2 border">Total URL Hits</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                    $totalUrls = $member?->shortUrls->count() ?? 0;
                    $totalHits = $member?->shortUrls->sum('hit_count') ?? 0;
                ?>
                        <tr>
                            <td class="px-4 py-2 border">
                                <?php echo e($member->name ?? 'N/A'); ?>

                            </td>
                            <td class="px-4 py-2 border">
                                <?php echo e($member->email ?? 'N/A'); ?>

                            </td>
                            <td class="px-4 py-2 border">
                                <?php echo e($member->role ?? 'N/A'); ?>

                            </td>
                            <td class="px-4 py-2 border">
                                <?php echo e($totalUrls ?? 'N/A'); ?>

                            </td>
                            <td class="px-4 py-2 border">
                                <?php echo e($totalHits ?? 'N/A'); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="px-4 py-2 border text-center text-gray-500">
                                No Admin data available.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>

        <div class="flex justify-between items-center mt-3 text-sm">
            <span class="text-sm text-gray-600">
                Showing <?php echo e($members->firstItem()); ?> to <?php echo e($members->lastItem()); ?>

                of <?php echo e($members->total()); ?>

            </span>
            <a href="<?php echo e(route('team.list.all')); ?>"
                class="px-3 py-1 border border-blue-500 text-blue-600 rounded hover:bg-blue-500 hover:text-white">View
                All</a>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pc\Music\url-shortener\resources\views\dashboard\admin-dashboard.blade.php ENDPATH**/ ?>